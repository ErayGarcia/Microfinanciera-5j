<!DOCTYPE html>
<html lang="es-MX">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="./src/css/style.css">
    <title>Document</title>
    <style>
    body {
        background-color: grey; /* Color de fondo para toda la página */
    }
        /* Estilo para el fondo del formulario */
    .container {
        background-color: #f5f5f5;
        border-radius: 10px;
        padding: 20px;
        margin-top: 30px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    /* Estilo para el botón "Guardar" */
    .btn-primary {
        background-color: green;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }

    /* Estilo para los campos de entrada */
    .form-control {
        border-radius: 5px;
        border: 1px solid #ccc;
        padding: 10px;
    }

    /* Estilo para las etiquetas */
    label {
        font-weight: bold;
    }

    /* Alineación del formulario en el centro de la página */
    .container {
        text-align: center;
    }

    /* Título del formulario */
    h1 {
        color: #007bff;
    }

    /* Espaciado entre elementos */
    .form-group {
        margin-bottom: 20px;
    }

    /* Ancho máximo del formulario en pantallas grandes */
    @media (min-width: 992px) {
        .container {
            max-width: 500px;
        }
    }
    @media screen and (min-width:992px){
      .nav-item {
      line-height:80px;
      }
    }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="headerNav">
  <div class="container-fluid">
    <a class="navbar-brand d-block d-lg-none" href="#">
      <img src="./src/vistas/img/lgo.png" height="80" />
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item">
          <a class="nav-link mx-2 active" aria-current="page" href="inicio.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link mx-2 active" href="Registrocliente.php">Registro Cliente</a>
        </li>
        <li class="nav-item d-none d-lg-block">
          <a class="nav-link mx-2" href="#">
            <img src="./src/vistas/img/lgo.png" width="80" height="80" />
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link mx-2 active" href="Seguimiento.php">Seguimiento de Prestamo</a>
        </li>
        <li class="nav-item">
          <a class="nav-link mx-2 active" href="#">Estado de Cuenta</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container">
        <h1 class="mt-5">Formulario de Registro</h1>
        <form action="procesar_registro.php" method="post">
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>
            <div class="form-group">
                <label for="nombre_usuario">Nombre de Usuario:</label>
                <input type="text" class="form-control" id="nombre_usuario" name="nombre_usuario" required>
            </div>
            <div class="form-group">
                <label for="apellido">Apellido:</label>
                <input type="text" class="form-control" id="apellido" name="apellido" required>
            </div>
            <div class="form-group">
                <label for="direccion">Dirección:</label>
                <input type="text" class="form-control" id="direccion" name="direccion" required>
            </div>
            <div class="form-group">
                <label for="telefono">Teléfono:</label>
                <input type="tel" class="form-control" id="telefono" name="telefono" required>
            </div>
            <input type="submit" class="btn btn-primary" value="Guardar">
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>