<?php

$conexion=new mysqli("localhost","root","","microfinanciera");
$conexion->set_charset("utf8");
?>